﻿=== Empire Cursor Set ===

By: Lightcm (http://www.rw-designer.com/user/73160)

Download: http://www.rw-designer.com/cursor-set/empire

Author's description:

My second set of cursor :)

11.06.18 Cursor Updated
Image changes and improvements.

Please report bugs in the comments.

Enjoy!

======Contact======
https://plus.google.com/+AlexaLightCm
https://lightcm.deviantart.com/
-> lightcm08@gmail.com

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.